﻿namespace Lexer
{
    public struct MemoryInfo
    {
        public string name;
        public decimal value;
    }
}
