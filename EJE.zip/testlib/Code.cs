﻿namespace testlib
{
    public static class Code
    {
        public static void Print(string message)
        {
            int na = 200;
           while(na!=0)
            {
                na--;
            }
           Console.WriteLine("Done");
        }
    }
}
